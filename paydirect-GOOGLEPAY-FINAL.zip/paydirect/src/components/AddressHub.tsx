import React, { useState, useEffect } from 'react';
import { 
  Plus, QrCode, Copy, ShieldCheck, Key, RefreshCw, Import, Trash2, 
  Search, CheckCircle2, Wallet, Info, FileCode, Check, Send, Sparkles, ArrowDownLeft
} from 'lucide-react';
import { Coin, Holding } from '../types';

interface AddressHubProps {
  coins: Coin[];
  holdings: Holding[];
  onAddTransaction: (
    type: 'SEND' | 'RECEIVE',
    symbol: string,
    amount: number,
    fiatAmount: number,
    details: string
  ) => void;
  showToast: (message: string, type: 'success' | 'info' | 'error') => void;
}

interface CryptoAddress {
  id: string;
  coinSymbol: string;
  address: string;
  label: string;
  createdAt: number;
  isGenerated: boolean;
  privateKey?: string;
  seedPhrase?: string;
  balance?: number;
}

export default function AddressHub({
  coins,
  holdings,
  onAddTransaction,
  showToast
}: AddressHubProps) {
  // Load or initialize addresses
  const [addresses, setAddresses] = useState<CryptoAddress[]>(() => {
    const saved = localStorage.getItem('cb_addresses');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as CryptoAddress[];
        return parsed.map(({ privateKey, seedPhrase, ...rest }) => rest);
      } catch {
        return [];
      }
    }
    return [
      {
        id: 'addr-1',
        coinSymbol: 'BTC',
        address: 'bc1q9rny26szrgl26u64mdg0cuhvpt2p77jwh792ka',
        label: 'My Default Bitcoin Deposit Wallet',
        createdAt: Date.now() - 30 * 24 * 60 * 60 * 1000,
        isGenerated: true,
        balance: 0.45
      },
      {
        id: 'addr-2',
        coinSymbol: 'ETH',
        address: '0x71C7656EC7ab88b098defB751B7401B5f6d1476B',
        label: 'Primary Ethereum Web3 Account',
        createdAt: Date.now() - 15 * 24 * 60 * 60 * 1000,
        isGenerated: true,
        balance: 2.12
      }
    ];
  });

  // Save changes
  useEffect(() => {
    // Never persist private keys or seed phrases in browser storage.
    const sanitized = addresses.map(({ privateKey, seedPhrase, ...rest }) => rest);
    localStorage.setItem('cb_addresses', JSON.stringify(sanitized));
  }, [addresses]);

  // States
  const [selectedCoin, setSelectedCoin] = useState('BTC');
  const [newLabel, setNewLabel] = useState('');
  const [importAddress, setImportAddress] = useState('');
  const [importPrivateKey, setImportPrivateKey] = useState('');
  const [importLabel, setImportLabel] = useState('');
  const [importCoin, setImportCoin] = useState('ETH');
  const [viewingDetail, setViewingDetail] = useState<CryptoAddress | null>(null);
  const [revealedPrivateKey, setRevealedPrivateKey] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Address generators based on coin standard
  const generateRandomAddress = (symbol: string) => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randStr = '';
    for (let i = 0; i < 28; i++) {
      randStr += chars[Math.floor(Math.random() * chars.length)];
    }

    switch (symbol) {
      case 'BTC':
        return `bc1q${randStr.slice(0, 24)}h792ka`;
      case 'ETH':
      case 'USDC':
        const hexChars = '0123456789abcdef';
        let hex = '';
        for (let i = 0; i < 38; i++) {
          hex += hexChars[Math.floor(Math.random() * hexChars.length)];
        }
        return `0x${hex}`;
      case 'SOL':
        const base58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
        let solAddr = '';
        for (let i = 0; i < 40; i++) {
          solAddr += base58[Math.floor(Math.random() * base58.length)];
        }
        return solAddr;
      case 'XRP':
        let xrpAddr = 'r';
        for (let i = 0; i < 33; i++) {
          xrpAddr += chars[Math.floor(Math.random() * chars.length)];
        }
        return xrpAddr;
      default:
        return `cb_${symbol.toLowerCase()}_${randStr}`;
    }
  };

  const generateRandomPrivateKey = (symbol: string) => {
    const hex = '0123456789abcdefABCDEF';
    let pk = '';
    for (let i = 0; i < 64; i++) {
      pk += hex[Math.floor(Math.random() * hex.length)];
    }
    return symbol === 'ETH' || symbol === 'USDC' ? `0x${pk}` : pk.slice(0, 48);
  };

  const generateRandomSeed = () => {
    const words = [
      'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract', 'absurd', 'abuse',
      'access', 'accident', 'account', 'accuse', 'achieve', 'acid', 'acoustic', 'acquire', 'across', 'act',
      'action', 'actor', 'actress', 'actual', 'adapt', 'add', 'addict', 'address', 'adjust', 'admit',
      'adopt', 'adore', 'adult', 'venture', 'basic', 'logic', 'focus', 'cream', 'solid', 'crisp', 'visual'
    ];
    let seed: string[] = [];
    for (let i = 0; i < 12; i++) {
      seed.push(words[Math.floor(Math.random() * words.length)]);
    }
    return seed.join(' ');
  };

  // Create brand new address
  const handleCreateAddress = () => {
    const newAddressStr = generateRandomAddress(selectedCoin);
    const newPk = generateRandomPrivateKey(selectedCoin);
    const newSeed = generateRandomSeed();

    const newAddrObj: CryptoAddress = {
      id: `addr-${Date.now()}`,
      coinSymbol: selectedCoin,
      address: newAddressStr,
      label: newLabel.trim() || `My Generated ${selectedCoin} Account`,
      createdAt: Date.now(),
      isGenerated: true,
      privateKey: newPk,
      seedPhrase: newSeed,
      balance: 0.0
    };

    setAddresses([newAddrObj, ...addresses]);
    setNewLabel('');
    showToast(`Created new secure ${selectedCoin} wallet address!`, 'success');
  };

  // Validate address formats
  const validateAddress = (addr: string, symbol: string): boolean => {
    if (!addr) return false;
    
    switch (symbol) {
      case 'ETH':
      case 'USDC':
        return /^0x[a-fA-F0-9]{40}$/.test(addr);
      case 'BTC':
        return /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$/.test(addr);
      case 'SOL':
        return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr);
      case 'XRP':
        return /^r[0-9a-zA-Z]{24,34}$/.test(addr);
      default:
        return addr.length > 10;
    }
  };

  // Import existing address
  const handleImportAddress = (e: React.FormEvent) => {
    e.preventDefault();

    if (!importAddress.trim()) {
      showToast('Please enter an address string.', 'error');
      return;
    }

    const isValid = validateAddress(importAddress.trim(), importCoin);
    if (!isValid) {
      showToast(`Invalid address format for ${importCoin}. Please review standard protocol schemas.`, 'error');
      return;
    }

    const newImportObj: CryptoAddress = {
      id: `addr-imp-${Date.now()}`,
      coinSymbol: importCoin,
      address: importAddress.trim(),
      label: importLabel.trim() || `Imported ${importCoin} Wallet`,
      createdAt: Date.now(),
      isGenerated: false,
      privateKey: undefined,
      balance: Math.random() * 2.5 // simulate an on-chain balance to track
    };

    setAddresses([newImportObj, ...addresses]);
    setImportAddress('');
    setImportPrivateKey('');
    setImportLabel('');
    if (importPrivateKey.trim()) {
      showToast('Private keys are not persisted in browser storage. Use external wallet custody for signing.', 'info');
    }
    showToast(`Imported ${importCoin} address successfully! Tracking on-chain index.`, 'success');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Simulate on-chain top-up
  const handleSimulateOnChainTopUp = (addressObj: CryptoAddress, topUpAmount: number) => {
    const coin = coins.find((c) => c.symbol === addressObj.coinSymbol);
    if (!coin) return;

    setAddresses(prev => 
      prev.map(a => a.id === addressObj.id ? { ...a, balance: (a.balance || 0) + topUpAmount } : a)
    );

    const fiatVal = topUpAmount * coin.price;
    onAddTransaction('RECEIVE', addressObj.coinSymbol, topUpAmount, fiatVal, `On-chain Deposit into address (****${addressObj.address.slice(-6)})`);
    showToast(`Received ${topUpAmount} ${addressObj.coinSymbol} deposit onto this address!`, 'success');
    
    // Update viewingDetail balance if it's the current one
    if (viewingDetail?.id === addressObj.id) {
      setViewingDetail(prev => prev ? { ...prev, balance: (prev.balance || 0) + topUpAmount } : null);
    }
  };

  const handleDeleteAddress = (id: string, label: string) => {
    setAddresses(addresses.filter(a => a.id !== id));
    if (viewingDetail?.id === id) {
      setViewingDetail(null);
    }
    showToast(`Deleted ${label} from monitoring.`, 'info');
  };

  const filteredAddresses = addresses.filter(addr => {
    const term = searchQuery.toLowerCase();
    return addr.label.toLowerCase().includes(term) ||
           addr.coinSymbol.toLowerCase().includes(term) ||
           addr.address.toLowerCase().includes(term);
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      {/* LEFT COLUMN: Manage & Create addresses */}
      <div className="lg:col-span-8 space-y-6">
        
        {/* Banner */}
        <div className="bg-[#0052FF] text-white p-6 rounded-3xl relative overflow-hidden shadow-sm">
          <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
            <Wallet className="w-48 h-48" />
          </div>
          <div className="max-w-md relative z-10">
            <span className="text-[10px] bg-white/20 text-white font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
              Coinbase Multi-Chain Address Manager
            </span>
            <h2 className="text-xl sm:text-2xl font-black mt-3 leading-tight">
              Create and Import Universal Blockchain Addresses
            </h2>
            <p className="text-xs text-blue-100 mt-2 leading-relaxed">
              Generate new deposit accounts with backup seed phrases or import existing public keys to track ledger entries, accounting histories, and mempool broadcasts.
            </p>
          </div>
        </div>

        {/* Search & Address List */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Tracked Accounts & Deposit Addresses</h3>
              <p className="text-xs text-gray-400 mt-0.5">Manage keys and import external nodes.</p>
            </div>
            
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search addresses, labels..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-50 border border-gray-200 text-xs sm:text-sm pl-9 pr-3 py-2 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0052FF]"
              />
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {filteredAddresses.length > 0 ? (
              filteredAddresses.map((addr) => {
                const coin = coins.find(c => c.symbol === addr.coinSymbol) || { name: addr.coinSymbol, color: '#333', price: 1 };
                return (
                  <div key={addr.id} className="py-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                    <div className="flex items-center space-x-3.5 flex-1 min-w-0">
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs font-mono shrink-0"
                        style={{ backgroundColor: coin.color }}
                      >
                        {addr.coinSymbol}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs sm:text-sm font-bold text-gray-900 truncate">
                            {addr.label}
                          </span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                            addr.isGenerated ? 'bg-blue-50 text-[#0052FF]' : 'bg-amber-50 text-amber-600'
                          }`}>
                            {addr.isGenerated ? 'Generated' : 'Imported'}
                          </span>
                        </div>
                        <p className="text-xs text-gray-400 font-mono truncate mt-0.5 max-w-xs sm:max-w-md">
                          {addr.address}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end space-x-4">
                      <div className="text-right">
                        <p className="text-xs font-bold text-gray-800 font-mono">
                          {(addr.balance || 0).toFixed(4)} {addr.coinSymbol}
                        </p>
                        <p className="text-[10px] text-gray-400 font-mono">
                          ≈ ${((addr.balance || 0) * coin.price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </p>
                      </div>

                      <div className="flex items-center space-x-1.5">
                        <button
                          onClick={() => handleCopy(addr.address)}
                          className="p-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200/80 rounded-lg text-gray-500 hover:text-gray-900 cursor-pointer"
                          title="Copy address"
                        >
                          {copiedText === addr.address ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                        </button>
                        <button
                          onClick={() => {
                            setViewingDetail(addr);
                            setRevealedPrivateKey(false);
                          }}
                          className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-[11px] rounded-lg cursor-pointer"
                        >
                          Keys & Sim
                        </button>
                        <button
                          onClick={() => handleDeleteAddress(addr.id, addr.label)}
                          className="p-1.5 text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 cursor-pointer"
                          title="Delete address"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-xs text-gray-400 font-medium bg-gray-50/50 rounded-xl border border-dashed border-gray-200">
                No addresses match your filter or search criteria.
              </div>
            )}
          </div>
        </div>

        {/* Generate and Import panel grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Create Address Panel */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-[#0052FF]">
                <Plus className="h-5 w-5" />
                <h4 className="text-xs sm:text-sm font-extrabold text-gray-900">Generate New Account</h4>
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Generate custom cryptographic address endpoints on Coinbase vault. All private keys are secured inside your browser local session.
              </p>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Target Blockchain Asset</label>
                <select
                  value={selectedCoin}
                  onChange={(e) => setSelectedCoin(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm font-semibold px-3 py-2.5 rounded-xl focus:outline-none cursor-pointer"
                >
                  {coins.map(c => (
                    <option key={c.symbol} value={c.symbol}>{c.name} ({c.symbol})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Account Label / Alias</label>
                <input
                  type="text"
                  placeholder="e.g. My Ledger Cold Storage Backup"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm px-3 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0052FF]"
                />
              </div>
            </div>

            <button
              onClick={handleCreateAddress}
              className="w-full mt-6 py-2.5 bg-[#0052FF] hover:bg-blue-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-xs transition-colors"
            >
              Generate Seed & Keys
            </button>
          </div>

          {/* Import External Address Panel */}
          <form onSubmit={handleImportAddress} className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-amber-500">
                <Import className="h-5 w-5" />
                <h4 className="text-xs sm:text-sm font-extrabold text-gray-900">Import On-Chain Address</h4>
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Import an external public key or address (such as MetaMasK, Trust Wallet) to track network confirmations and transactions.
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Asset</label>
                  <select
                    value={importCoin}
                    onChange={(e) => setImportCoin(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm font-semibold px-3 py-2.5 rounded-xl focus:outline-none cursor-pointer"
                  >
                    {coins.map(c => (
                      <option key={c.symbol} value={c.symbol}>{c.symbol}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Account Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. External Hotwallet"
                    value={importLabel}
                    onChange={(e) => setImportLabel(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm px-3 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0052FF]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Public Key / Address String</label>
                <input
                  type="text"
                  required
                  placeholder={importCoin === 'ETH' ? '0x...' : importCoin === 'BTC' ? 'bc1...' : 'Enter public address'}
                  value={importAddress}
                  onChange={(e) => setImportAddress(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm px-3 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0052FF] font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Private Key (Optional - Offline Only)</label>
                <input
                  type="password"
                  placeholder="For local client-side signing and address review"
                  value={importPrivateKey}
                  onChange={(e) => setImportPrivateKey(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 text-xs sm:text-sm px-3 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0052FF] font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-6 py-2.5 bg-gray-800 hover:bg-slate-900 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-xs transition-colors"
            >
              Link & Track Address
            </button>
          </form>

        </div>

      </div>

      {/* RIGHT COLUMN: Key inspector and wallet operations */}
      <div className="lg:col-span-4">
        
        {viewingDetail ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs space-y-5 animate-slide-up">
            <div className="flex justify-between items-start border-b border-gray-100 pb-3">
              <div>
                <span className="text-[10px] text-gray-400 font-mono font-bold uppercase tracking-widest">{viewingDetail.coinSymbol} KEYCHAIN CARD</span>
                <h4 className="text-sm font-bold text-gray-900 mt-0.5">{viewingDetail.label}</h4>
              </div>
              <button 
                onClick={() => setViewingDetail(null)}
                className="text-xs text-gray-400 hover:text-gray-900 font-bold"
              >
                Close
              </button>
            </div>

            {/* QR Code and Address display */}
            <div className="flex flex-col items-center py-2 space-y-3.5">
              <div className="p-3.5 bg-slate-50 border border-gray-200/60 rounded-xl">
                <QrCode className="w-36 h-36 text-gray-900" />
              </div>
              
              <div className="w-full">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider block mb-1 text-center">Copy Public Endpoint Address</span>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-200/80 text-xs flex justify-between items-center font-mono">
                  <span className="truncate pr-4 flex-1">{viewingDetail.address}</span>
                  <button
                    onClick={() => handleCopy(viewingDetail.address)}
                    className="p-1 hover:bg-white rounded-md border border-transparent hover:border-gray-200 text-gray-500 cursor-pointer"
                  >
                    {copiedText === viewingDetail.address ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Private credentials container */}
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 space-y-3.5 text-xs">
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-gray-400 font-bold uppercase">Private Seed Word Backup</span>
                  <span className="text-[9px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded-md font-bold uppercase">Secured</span>
                </div>
                {viewingDetail.seedPhrase ? (
                  <p className="text-[10px] font-mono bg-white p-2 border border-gray-200 rounded-lg mt-1.5 leading-relaxed text-gray-600 select-all">
                    {viewingDetail.seedPhrase}
                  </p>
                ) : (
                  <p className="text-[10px] text-gray-400 italic mt-1 leading-relaxed">
                    This is an imported external node. Seed words are not accessible locally.
                  </p>
                )}
              </div>

              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-gray-400 font-bold uppercase">Private Key (ECDSA / Ed25519)</span>
                  <button
                    onClick={() => setRevealedPrivateKey(!revealedPrivateKey)}
                    className="text-[10px] text-[#0052FF] hover:underline cursor-pointer font-bold"
                  >
                    {revealedPrivateKey ? 'Hide' : 'Reveal Key'}
                  </button>
                </div>
                
                {revealedPrivateKey ? (
                  <p className="text-[10px] font-mono bg-red-50/50 border border-red-100 p-2 rounded-lg mt-1.5 text-red-700 break-all select-all font-semibold">
                    {viewingDetail.privateKey || 'No Private key saved for this imported address.'}
                  </p>
                ) : (
                  <div className="bg-gray-200 text-gray-400 p-2 rounded-lg mt-1.5 text-center select-none font-mono tracking-widest text-[9px]">
                    ••••••••••••••••••••••••••••••••••••••••
                  </div>
                )}
              </div>
            </div>

            {/* Sim Faucet container */}
            <div className="border border-dashed border-gray-200 rounded-xl p-4 bg-gray-50/20 text-center space-y-3">
              <div className="flex items-center justify-center space-x-1 text-green-600 text-[11px] font-extrabold uppercase">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Record Wallet Funding</span>
              </div>
              <p className="text-[10px] text-gray-400 leading-relaxed max-w-xs mx-auto">
                Record an on-chain funding event to verify ledger logging, transaction processing, and balance updates.
              </p>
              
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleSimulateOnChainTopUp(viewingDetail, viewingDetail.coinSymbol === 'BTC' ? 0.1 : viewingDetail.coinSymbol === 'ETH' ? 1.0 : 10.0)}
                  className="py-1.5 bg-white border border-gray-200 text-gray-800 text-[10px] font-bold rounded-lg hover:bg-gray-100 cursor-pointer transition-colors flex items-center justify-center space-x-1"
                >
                  <ArrowDownLeft className="h-3 w-3 text-green-600" />
                  <span>+{viewingDetail.coinSymbol === 'BTC' ? '0.1' : viewingDetail.coinSymbol === 'ETH' ? '1.0' : '10'} {viewingDetail.coinSymbol}</span>
                </button>
                <button
                  onClick={() => handleSimulateOnChainTopUp(viewingDetail, viewingDetail.coinSymbol === 'BTC' ? 0.5 : viewingDetail.coinSymbol === 'ETH' ? 5.0 : 50.0)}
                  className="py-1.5 bg-white border border-gray-200 text-gray-800 text-[10px] font-bold rounded-lg hover:bg-gray-100 cursor-pointer transition-colors flex items-center justify-center space-x-1"
                >
                  <ArrowDownLeft className="h-3 w-3 text-green-600" />
                  <span>+{viewingDetail.coinSymbol === 'BTC' ? '0.5' : viewingDetail.coinSymbol === 'ETH' ? '5.0' : '50'} {viewingDetail.coinSymbol}</span>
                </button>
              </div>
            </div>

          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs text-center py-12 space-y-4">
            <div className="w-12 h-12 bg-blue-50 text-[#0052FF] rounded-full flex items-center justify-center mx-auto">
              <Key className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-gray-900">Keychain & Balance Inspector</h4>
              <p className="text-xs text-gray-400 mt-2 max-w-xs mx-auto">
                Select an address in the list on the left to inspect its cryptographic keys, back up seed words, scan QR codes, or record on-chain wallet funding.
              </p>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
