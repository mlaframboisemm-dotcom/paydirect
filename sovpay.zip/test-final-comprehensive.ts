/**
 * Final Production Test Suite - All Features with Correct Payloads
 */

import https from 'https';

const BASE_URL = 'https://www.sovereigns.ca';

interface TestResult {
  name: string;
  category: string;
  endpoint: string;
  method: string;
  payload?: string;
  status: 'PASS' | 'FAIL';
  httpStatus: number;
  responseTime: number;
  body: string;
}

const results: TestResult[] = [];

function request(
  method: string,
  path: string,
  data?: string
): Promise<{ status: number; body: string; responseTime: number }> {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    };

    const req = https.request(BASE_URL + path, options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        const responseTime = Date.now() - startTime;
        resolve({
          status: res.statusCode || 500,
          body,
          responseTime,
        });
      });
    });

    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function test(
  name: string,
  category: string,
  endpoint: string,
  method: string,
  payload?: string
) {
  try {
    const { status, body, responseTime } = await request(method, endpoint, payload);
    const isPassed = status >= 200 && status < 300;

    results.push({
      name,
      category,
      endpoint,
      method,
      payload,
      status: isPassed ? 'PASS' : 'FAIL',
      httpStatus: status,
      responseTime,
      body: body.substring(0, 300),
    });

    console.log(`${isPassed ? '✅' : '❌'} ${name}: HTTP ${status} (${responseTime}ms)`);
  } catch (error: any) {
    console.log(`🔴 ${name}: ${error.message}`);
    results.push({
      name,
      category,
      endpoint,
      method,
      payload,
      status: 'FAIL',
      httpStatus: 0,
      responseTime: 0,
      body: error.message,
    });
  }
}

async function runTests() {
  console.log('🔬 COMPREHENSIVE PRODUCTION TEST SUITE\n');

  // ===== HEALTH & VERIFICATION =====
  console.log('=== Health & Verification ===');
  await test('Health Check', 'health', '/api/health', 'GET');
  await test('Verification Status', 'verification', '/api/verification/status', 'GET');
  await test('Verification Report', 'verification', '/api/verification/report', 'GET');
  await test('Infrastructure Status', 'verification', '/api/verification/infrastructure', 'GET');

  // ===== MARKET DATA =====
  console.log('\n=== Market Data ===');
  await test('Get Prices', 'market', '/api/prices', 'GET');

  // ===== CONFIGURATION =====
  console.log('\n=== Configuration ===');
  await test('Marshall Config', 'config', '/api/marshall/config', 'GET');
  await test('Marshall Gateway', 'config', '/api/marshall/gateway', 'GET');
  await test('Mempool List', 'config', '/api/mempool/list', 'GET');

  // ===== EXCHANGES (with correct payloads) =====
  console.log('\n=== Exchanges ===');
  await test('Get Exchange Secrets', 'exchanges', '/api/exchanges/secrets', 'GET');
  await test('Exchange Sync - Coinbase', 'exchanges', '/api/exchanges/sync', 'POST', 
    JSON.stringify({ exchange: 'coinbase' }));
  await test('Exchange Sync - Kraken', 'exchanges', '/api/exchanges/sync', 'POST',
    JSON.stringify({ exchange: 'kraken' }));
  
  // Trade endpoint with correct format
  await test('Trade - Buy BTC', 'exchanges', '/api/exchanges/trade', 'POST',
    JSON.stringify({ action: 'buy', symbol: 'BTC', amount: '0.001', exchange: 'coinbase' }));
  
  await test('Trade - Sell ETH', 'exchanges', '/api/exchanges/trade', 'POST',
    JSON.stringify({ action: 'sell', symbol: 'ETH', amount: '0.01', exchange: 'kraken' }));

  // ===== WALLET =====
  console.log('\n=== Wallet Operations ===');
  await test('Wallet Send - Valid Address', 'wallet', '/api/wallet/send', 'POST',
    JSON.stringify({ 
      asset: 'ETH',
      amount: '0.0001', 
      toAddress: '0x58B178F7EEe92fe888c0A1684D5FE6b78C0Ff99f',
      note: 'Test transfer'
    }));

  await test('Wallet Send - Invalid Address', 'wallet', '/api/wallet/send', 'POST',
    JSON.stringify({ 
      asset: 'ETH',
      amount: '0.0001', 
      toAddress: 'invalid-address',
      note: 'Test'
    }));

  // ===== ATM =====
  console.log('\n=== ATM Operations ===');
  await test('ATM Voucher - CAD', 'atm', '/api/atm/voucher', 'POST',
    JSON.stringify({ amount: 100, asset: 'CAD' }));

  await test('ATM Voucher - USD', 'atm', '/api/atm/voucher', 'POST',
    JSON.stringify({ amount: 50, asset: 'USD', userId: 'test-user' }));

  await test('ATM Voucher - Invalid Amount', 'atm', '/api/atm/voucher', 'POST',
    JSON.stringify({ amount: 0, asset: 'CAD' }));

  // ===== SECURITY =====
  console.log('\n=== Security Operations ===');
  await test('Reveal Keys', 'security', '/api/security/reveal-keys', 'POST',
    JSON.stringify({ password: 'test-password' }));

  // ===== E-TRANSFER =====
  console.log('\n=== E-Transfer Operations ===');
  await test('E-Transfer List', 'etransfer', '/api/exchanges/etransfer/list', 'GET');
  await test('E-Transfer Direct Deposit', 'etransfer', '/api/exchanges/etransfer/deposit-direct', 'POST',
    JSON.stringify({ amount: 100, targetBank: 'RBC' }));

  // ===== ERROR HANDLING =====
  console.log('\n=== Error Handling ===');
  await test('404 Not Found', 'error', '/api/does-not-exist', 'GET');
  await test('400 Bad Request', 'error', '/api/wallet/send', 'POST', JSON.stringify({}));

  // ===== RESULTS =====
  console.log('\n========== FINAL RESULTS ==========' );
  const passed = results.filter((r) => r.status === 'PASS').length;
  const failed = results.filter((r) => r.status === 'FAIL').length;
  const total = results.length;

  console.log(`\nTotal Tests: ${total}`);
  console.log(`✅ Passed: ${passed} (${((passed / total) * 100).toFixed(1)}%)`);
  console.log(`❌ Failed: ${failed} (${((failed / total) * 100).toFixed(1)}%)`);

  console.log('\n--- By Category ---');
  const byCategory = results.reduce(
    (acc: Record<string, TestResult[]>, r) => {
      if (!acc[r.category]) acc[r.category] = [];
      acc[r.category].push(r);
      return acc;
    },
    {}
  );

  Object.entries(byCategory).forEach(([cat, tests]) => {
    const catPassed = tests.filter((t) => t.status === 'PASS').length;
    const percent = ((catPassed / tests.length) * 100).toFixed(0);
    console.log(`  ${cat}: ${catPassed}/${tests.length} (${percent}%)`);
  });

  console.log('\n--- Performance ---');
  const times = results.map((r) => r.responseTime);
  const avg = times.reduce((a, b) => a + b, 0) / times.length;
  console.log(`  Avg: ${avg.toFixed(0)}ms | Min: ${Math.min(...times)}ms | Max: ${Math.max(...times)}ms`);

  console.log(`\n🎯 CERTIFICATION: ${failed === 0 ? '✅ PRODUCTION READY' : `⚠️ REVIEW - ${failed} failures`}`);
  console.log(`Generated: ${new Date().toISOString()}`);

  // ===== DETAILED OUTPUT FOR DEBUGGING =====
  console.log('\n========== DETAILED RESULTS ==========' );
  results.forEach((r) => {
    console.log(`\n[${r.status}] ${r.name}`);
    console.log(`  Endpoint: ${r.method} ${r.endpoint}`);
    console.log(`  Status: HTTP ${r.httpStatus} | Time: ${r.responseTime}ms`);
    if (r.payload) console.log(`  Payload: ${r.payload.substring(0, 100)}`);
    console.log(`  Response: ${r.body}`);
  });
}

runTests().catch(console.error);
